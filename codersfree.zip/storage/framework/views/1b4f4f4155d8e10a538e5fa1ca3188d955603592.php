<?php $__env->startSection('title', 'Course Free'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear nueva categoría</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 col-lg-8 col-xl-6">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(['route' => 'admin.categories.store']); ?>


                        <?php echo $__env->make('admin.categories.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="mt-4">
                            <?php echo Form::submit('Crear categoría', ['class' => 'btn btn-primary']); ?>

                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>