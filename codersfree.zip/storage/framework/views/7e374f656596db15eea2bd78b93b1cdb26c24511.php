<?php $__env->startSection('title', 'Course Free'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Asignar rol</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 col-lg-8 col-xl-6">

            <?php if(session('success')): ?>
                <div class="alert alert-success mb-4 alert-dismissible fade show" role="alert">
                    <strong>Holy guacamole!</strong> <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <?php echo Form::model($user, ['route' => ['admin.users.update', $user], 'method' => 'put']); ?>

                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label">Nombre</label>
                            <div class="col-sm-9">
                                <input type="text" id="name" class="form-control" value="<?php echo e($user->name); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label">Lista de roles</label>
                            <div class="col-sm-9">
                                    <ul class="list-unstyled">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="custom-control custom-checkbox">
                                                    <?php echo Form::checkbox('roles[]', $role->id, null, ['id' => 'role-' . $role->id, 'class' => 'custom-control-input']); ?>

                                                    <?php echo Form::label('role-' . $role->id, $role->name, ['class' => 'custom-control-label']); ?>

                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>