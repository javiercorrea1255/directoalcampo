<div>
    <h1 class="text-2xl font-bold mb-8">Lecciones</h1>

    <?php $__empty_1 = true; $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="bg-gray-50 rounded shadow mb-4" x-data="{open: <?php echo e(($loop->first ? 'true' : 'false')); ?> }">
            <?php if($section->id == $item->id): ?>
                
                <header class="flex justify-between items-center px-4 py-3">
                    <form class="flex-1" wire:submit.prevent="update">
                        <input wire:model="section.name" type="text" class="form-input <?php if($errors->has('section.name')): ?> invalid <?php endif; ?>" placeholder="Escribir...">
                        <?php $__errorArgs = ['section.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>
                </header>
            <?php else: ?>
                
                <div class="flex justify-between items-center">
                    <button @click="open = !open" type="button" class="flex-1 text-left hover:bg-gray-100 rounded px-4 py-3 cursor-pointer focus:outline-none focus:ring-2 ring-gray-300">
                        <h1><b><?php echo e($item->name); ?></b></h1>
                    </button>
                    <div class="flex-shrink-0 select-none ml-4">
                        <button wire:click="edit(<?php echo e($item); ?>)" class="p-1 text-gray-400 rounded hover:text-blue-500 focus:text-blue-500 focus:ring-2 ring-blue-300 focus:outline-none" type="button">
                            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                        </button>
                        <button wire:click="destroy(<?php echo e($item); ?>)" class="p-1 text-gray-400 rounded hover:text-red-500 focus:text-red-500 focus:ring-2 ring-red-300 focus:outline-none" type="button">
                            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </button>
                    </div>
                </div>

                <div x-show="open">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.courses-lesson', ['section' => $item])->html();
} elseif ($_instance->childHasBeenRendered($item->id)) {
    $componentId = $_instance->getRenderedChildComponentId($item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.courses-lesson', ['section' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild($item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            <?php endif; ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="text-center">
        Este curso aun no tiene lecciones.
    </div>
    <?php endif; ?>

    
    <div class="mt-4" x-data="{open: false}">
        <div class="text-center mb-3">
            <button class="btn btn-green" type="button" @click="open = true; if (open) $nextTick(()=>{ $refs.nameInput.focus() });" x-show="!open">
                <svg class="inline w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                </svg> Agregar nueva sección
            </button>
        </div>
        <article class="bg-gray-50 rounded shadow px-4 py-3 mb-3" x-show="open">
            <h1 class="text-lg font-bold mb-3">Nueva sección</h1>
            <div class="flex flex-wrap gap-2 mb-3">
                <div class="flex-1">
                    <input wire:model="name" x-ref="nameInput" type="text" class="form-input <?php if($errors->has('name')): ?> invalid <?php endif; ?>" placeholder="Nombre de la sección">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <div class="flex gap-2">
                        <button class="btn" @click="open = false" wire:click="resetName">Cancelar</button>
                        <button class="btn btn-blue" wire:click="store">Guardar</button>
                    </div>
                </div>
            </div>
        </article>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/livewire/instructor/courses-curriculum.blade.php ENDPATH**/ ?>