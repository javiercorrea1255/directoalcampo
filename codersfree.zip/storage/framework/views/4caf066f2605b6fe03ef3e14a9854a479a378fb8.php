<?php if (isset($component)) { $__componentOriginal7bb489bab0e37f83489c86b0eec0f539e64bbdc5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InstructorLayout::class, ['course' => $course]); ?>
<?php $component->withName('instructor-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-8">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.course-goals', ['course' => $course])->html();
} elseif ($_instance->childHasBeenRendered('course-goals' . $course->id)) {
    $componentId = $_instance->getRenderedChildComponentId('course-goals' . $course->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('course-goals' . $course->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('course-goals' . $course->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.course-goals', ['course' => $course]);
    $html = $response->html();
    $_instance->logRenderedChild('course-goals' . $course->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div class="mb-8">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.course-requirements', ['course' => $course])->html();
} elseif ($_instance->childHasBeenRendered('course-requirements' . $course->id)) {
    $componentId = $_instance->getRenderedChildComponentId('course-requirements' . $course->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('course-requirements' . $course->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('course-requirements' . $course->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.course-requirements', ['course' => $course]);
    $html = $response->html();
    $_instance->logRenderedChild('course-requirements' . $course->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.course-audiences', ['course' => $course])->html();
} elseif ($_instance->childHasBeenRendered('course-audiences' . $course->id)) {
    $componentId = $_instance->getRenderedChildComponentId('course-audiences' . $course->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('course-audiences' . $course->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('course-audiences' . $course->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.course-audiences', ['course' => $course]);
    $html = $response->html();
    $_instance->logRenderedChild('course-audiences' . $course->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php if (isset($__componentOriginal7bb489bab0e37f83489c86b0eec0f539e64bbdc5)): ?>
<?php $component = $__componentOriginal7bb489bab0e37f83489c86b0eec0f539e64bbdc5; ?>
<?php unset($__componentOriginal7bb489bab0e37f83489c86b0eec0f539e64bbdc5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/instructor/courses/goals.blade.php ENDPATH**/ ?>