<div>
    <section class="card relative">
        <div wire:loading.flex class="absolute w-full h-full bg-gray-100 bg-opacity-25 z-30  items-center justify-center">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.spinner','data' => ['size' => '20']]); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['size' => '20']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
         </div>
        <div class="px-6 py-4 bg-gray-50">
            <h1 class="text-gray-700 text-lg font-bold">Métodos de pago agregados</h1>
                        </div>
        <div class="card-body divide-y divide-gray-200">

            <?php $__empty_1 = true; $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
            <article class="text-sm text-gray-700 py-2 flex justify-between items-center">
               <div>
                <h1> <span class="font-bold"><?php echo e($paymentMethod->billing_details->name); ?></span> xxx-<?php echo e($paymentMethod->card->last4); ?>

                   <?php if($paymentMethod->id == auth()->user()->defaultPaymentMethod()->id): ?>
                    (Predeterminado)
                    <?php endif; ?>
                </h1>
                <p>Expira <?php echo e($paymentMethod->card->exp_month); ?>//<?php echo e($paymentMethod->card->exp_year); ?></p>


               </div>

               <div class="grid grid-cols-2 border border-gray-200 rounded text-gray-500 divide-x divide-gray-200">
                
                <?php if (! ($paymentMethod->id == auth()->user()->defaultPaymentMethod()->id)): ?>
                <i class="fas fa-star cursor-pointer p-3 hover:text-gray-700" wire:click="defaultPaymentMethod('<?php echo e($paymentMethod->id); ?>')" ></i>
                <i class="fas fa-trash cursor-pointer p-3 hover:text-gray-700 " wire:click="deletePaymentMethod('<?php echo e($paymentMethod->id); ?>')"></i>
                <?php endif; ?>
               
  

                
               </div>
            </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <article class="p-2">
                    <h1 class="text-sm text-gray-700">No cuenta con ningún método de pago</h1>
                </article>
           
            <?php endif; ?>


        </div>

    </section>
</div>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/livewire/payment-method-list.blade.php ENDPATH**/ ?>