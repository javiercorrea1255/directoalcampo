<?php $attributes = $attributes->exceptProps(['name', 'price']); ?>
<?php foreach (array_filter((['name', 'price']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="w-full">

    <?php if(auth()->user()->hasDefaultPaymentMethod()): ?>
        
    

    <?php if(auth()->user()->subscribed($name)): ?>
        <?php if(auth()->user()->subscribedToPrice($price, $name)): ?>

        <?php if(auth()->user()->subscription($name)->onGracePeriod()): ?>
        
        <button wire:click="resuminSubscription('<?php echo e($name); ?>')"
        wire:loading.remove
            wire:target="resuminSubscription('<?php echo e($name); ?>')"
            class="font-bold bg-red-600 hover:bg-red-700 text-white rounded-md px-10 py-2 transition-colors w-full flex items-center justify-center">
            Reanudar plan
        </button>

        <button  wire:loading.flex
            wire:target="resuminSubscription('<?php echo e($name); ?>')"
            class="font-bold bg-red-600 hover:bg-red-700 text-white rounded-md px-10 py-2 transition-colors w-full  items-center justify-center">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.spinner','data' => ['size' => '6','class' => 'mr-2']]); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['size' => '6','class' => 'mr-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            Reanudar plan
        </button>
        <?php else: ?>
            
       


        <button wire:click="cancellingSubscription('<?php echo e($name); ?>')"
        wire:loading.remove
            wire:target="cancellingSubscription('<?php echo e($name); ?>')"
            class="font-bold bg-red-600 hover:bg-red-700 text-white rounded-md px-10 py-2 transition-colors w-full flex items-center justify-center">
            Cancelar
        </button>

        <button  wire:loading.flex
            wire:target="cancellingSubscription('<?php echo e($name); ?>')"
            class="font-bold bg-red-600 hover:bg-red-700 text-white rounded-md px-10 py-2 transition-colors w-full  items-center justify-center">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.spinner','data' => ['size' => '6','class' => 'mr-2']]); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['size' => '6','class' => 'mr-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            Cancelar
        </button>

        <?php endif; ?>
        
        <?php else: ?>
            <button wire:click="changingPlans('<?php echo e($name); ?>', '<?php echo e($price); ?>')"
            wire:loading.remove
                wire:target="changingPlans('<?php echo e($name); ?>', '<?php echo e($price); ?>')"
                class="font-bold bg-gray-600 hover:bg-gray-700 text-white rounded-md px-10 py-2 transition-colors w-full flex items-center justify-center">
                Cambiar de plan
            </button>

            <button  wire:loading.flex
                wire:target="changingPlans('<?php echo e($name); ?>', '<?php echo e($price); ?>')"
                class="font-bold bg-gray-600 hover:bg-gray-700 text-white rounded-md px-10 py-2 transition-colors w-full  items-center justify-center">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.spinner','data' => ['size' => '6','class' => 'mr-2']]); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['size' => '6','class' => 'mr-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                Cambiar de plan
            </button>
        <?php endif; ?>
    <?php else: ?>
        
            <button  wire:click="newSubscription('<?php echo e($name); ?>', '<?php echo e($price); ?>')" 
                wire:loading.remove
                wire:target="newSubscription('<?php echo e($name); ?>', '<?php echo e($price); ?>')"
                class="font-bold bg-gray-600 hover:bg-gray-700 text-white rounded-md px-10 py-2 transition-colors w-full flex items-center justify-center">
                Suscríbete
            </button>


            <button  wire:loading.flex
                wire:target="newSubscription('<?php echo e($name); ?>', '<?php echo e($price); ?>')"
                class="font-bold bg-gray-600 hover:bg-gray-700 text-white rounded-md px-10 py-2 transition-colors w-full  items-center justify-center">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.spinner','data' => ['size' => '6','class' => 'mr-2']]); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['size' => '6','class' => 'mr-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                Suscríbete
            </button>
    <?php endif; ?>


    <?php else: ?>
    <button 
                class="font-bold bg-gray-600 hover:bg-gray-700 text-white rounded-md px-10 py-2 transition-colors w-full flex items-center justify-center">
                Agregar Método de pago
            </button>
        
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/components/button-subscription.blade.php ENDPATH**/ ?>