<?php $attributes = $attributes->exceptProps(['size'=>'64']); ?>
<?php foreach (array_filter((['size'=>'64']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<div <?php echo e($attributes->merge(["class"=>"loader ease-linear rounded-full border-8 border-t-8 border-gray-200 h-$size w-$size"
])); ?>></div><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/components/spinner.blade.php ENDPATH**/ ?>