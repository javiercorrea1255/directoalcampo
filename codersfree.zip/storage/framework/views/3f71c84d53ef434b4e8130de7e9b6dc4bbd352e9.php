<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    
    <section class="bg-cover bg-center" style="background-image: url('<?php echo e(asset('img/courses/pexels-karolina-grabowska-4207908.jpg')); ?>');">
        <div class="max-w-7xl mx-auto px-4 py-36 sm:px-6 lg:px-8 text-white">
            <div class="w-full md:w-3/4 lg:w-1/2">
                <h1 class="font-bold text-4xl">Los mejores del sector agrícola.</h1>
                <p class="text-lg mt-2 mb-4">Si estás buscando potenciar tus conocimientos y actualizarte, has llegado al lugar adecuado. Encuentra cursos y proyectos que te ayudarán en ese proceso</p>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('bUNvDLl')) {
    $componentId = $_instance->getRenderedChildComponentId('bUNvDLl');
    $componentTag = $_instance->getRenderedChildComponentTagName('bUNvDLl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bUNvDLl');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('bUNvDLl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
        </div>
    </section>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('courses-index')->html();
} elseif ($_instance->childHasBeenRendered('CdobLxa')) {
    $componentId = $_instance->getRenderedChildComponentId('CdobLxa');
    $componentTag = $_instance->getRenderedChildComponentTagName('CdobLxa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CdobLxa');
} else {
    $response = \Livewire\Livewire::mount('courses-index');
    $html = $response->html();
    $_instance->logRenderedChild('CdobLxa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/courses/index.blade.php ENDPATH**/ ?>