<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1 style="color:green"><b>Enhorabuena!</b></h1>
    <p>Su curso <b><?php echo e($course->title); ?></b> ha sido aprobado.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/mail/approved-course.blade.php ENDPATH**/ ?>