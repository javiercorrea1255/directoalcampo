<?php $attributes = $attributes->exceptProps(['course']); ?>
<?php foreach (array_filter((['course']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<article class="card flex flex-col">
    <img class="h-36 w-full object-cover" src="<?php echo e(Storage::url($course->image->url)); ?>" alt="">
    <div class="card-body flex-1 flex flex-col justify-between">
        <div>
            <h1 class="card-title"><?php echo e(Str::limit($course->title, 40)); ?></h1>
            <p class="text-gray-500 text-sm mb-2">Prof: <?php echo e($course->teacher->name); ?></p>
        </div>
        <div>
            <div class="flex">
                <ul class="flex text-sm">
                    <li class="mr-1">
                        <svg class="text-<?php echo e($course->rating >= 1 ? 'yellow' : 'gray'); ?>-300" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                        </svg>
                    </li>
                    <li class="mr-1">
                        <svg class="text-<?php echo e($course->rating >= 2 ? 'yellow' : 'gray'); ?>-300" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                        </svg>
                    </li>
                    <li class="mr-1">
                        <svg class="text-<?php echo e($course->rating >= 3 ? 'yellow' : 'gray'); ?>-300" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                        </svg>
                    </li>
                    <li class="mr-1">
                        <svg class="text-<?php echo e($course->rating >= 4 ? 'yellow' : 'gray'); ?>-300" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                        </svg>
                    </li>
                    <li class="mr-1">
                        <svg class="text-<?php echo e($course->rating == 5 ? 'yellow' : 'gray'); ?>-300" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                        </svg>
                    </li>
                </ul>
                <p class="text-sm text-gray-500 ml-auto">(<?php echo e($course->students_count); ?>)</p>
            </div>

                <?php if($course->price->value == 0): ?>
                    <p class="font-bold uppercase text-green-500 my-3">Gratis</p>
                <?php else: ?>
                    <p class="font-bold uppercase my-3">MXN$ <?php echo e($course->price->value); ?></p>
                <?php endif; ?>

            <a class="btn btn-blue btn-block" href="<?php echo e(route('courses.show', $course)); ?>">Más información</a>
        </div>
    </div>
</article>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/components/course-card.blade.php ENDPATH**/ ?>