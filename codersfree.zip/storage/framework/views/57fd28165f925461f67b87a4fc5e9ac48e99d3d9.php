<div class="mb-4">
    <?php echo Form::label('title', 'Título del curso'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-input mt-1' . ($errors->has('title') ? ' invalid' : '')]); ?>

    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-4">
    <?php echo Form::label('slug', 'Slug'); ?>

    <?php echo Form::text('slug', null, ['class' => 'form-input mt-1' . ($errors->has('slug') ? ' invalid' : ''), 'readonly' => 'readonly']); ?>

    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-4">
    <?php echo Form::label('subtitle', 'Subtítulo'); ?>

    <?php echo Form::text('subtitle', null, ['class' => 'form-input mt-1' . ($errors->has('subtitle') ? ' invalid' : '')]); ?>

    <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-4">
    <?php echo Form::label('description', 'Descripción'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-input mt-1' . ($errors->has('description') ? ' invalid' : '')]); ?>

    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-5 my-8">
    <div>
        <?php echo Form::label('category_id', 'Categoria'); ?>

        <?php echo Form::select('category_id', $categories, null, ['class' => 'form-input']); ?>

    </div>
    <div>
        <?php echo Form::label('level_id', 'Nivel'); ?>

        <?php echo Form::select('level_id', $levels, null, ['class' => 'form-input']); ?>

    </div>
    <div>
        <?php echo Form::label('price_id', 'Precio'); ?>

        <?php echo Form::select('price_id', $prices, null, ['class' => 'form-input']); ?>

    </div>
</div>

<h1 class="text-2xl font-bold mb-8">Portada del curso</h1>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
    <figure>
        <?php if(isset($course->image)): ?>
            <img id="picture" class="w-full h-64 object-cover object-center" src="<?php echo e(Storage::url($course->image->url)); ?>">
            <?php else: ?>
            <img id="picture" class="w-full h-64 object-cover object-center" src="<?php echo e(asset('img/courses/placeholder-course-image.png')); ?>">
        <?php endif; ?>
    </figure>
    <div>
        <?php echo Form::label('file', 'Seleccionar imagen', ['class' =>  ($errors->has('file') ? 'text-red-500' : '')]); ?>

        <?php echo Form::file('file', ['class' => 'block mt-1', 'accept' => 'image/*']); ?>

        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/instructor/courses/partials/form.blade.php ENDPATH**/ ?>