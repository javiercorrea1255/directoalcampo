<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-12">
        <div class="card">
            <div class="card-body">
                <h1 class="text-2xl font-bold mb-8">Nuevo curso</h1>

                <?php echo Form::open(['route' => 'instructor.courses.store', 'files' => true, 'autocomplete' => 'off']); ?>


                    <?php echo Form::hidden('user_id', auth()->user()->id); ?>


                    <?php echo $__env->make('instructor.courses.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="flex justify-end mt-12">
                        <?php echo Form::submit('Crear curso', ['class' => 'btn btn-blue']); ?>

                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

     <?php $__env->slot('js'); ?> 

        <script src="https://cdn.ckeditor.com/ckeditor5/25.0.0/classic/ckeditor.js"></script>
        <script src="<?php echo e(asset('js/instructor/courses/form.js')); ?>"></script>

     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/instructor/courses/create.blade.php ENDPATH**/ ?>