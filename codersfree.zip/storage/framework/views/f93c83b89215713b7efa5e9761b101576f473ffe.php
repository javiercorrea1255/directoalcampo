<?php $__env->startSection('title', 'Course Free'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Course Free - Admin Panel</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Welcome to Course Free - Admin Panel</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hello world!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/admin/index.blade.php ENDPATH**/ ?>