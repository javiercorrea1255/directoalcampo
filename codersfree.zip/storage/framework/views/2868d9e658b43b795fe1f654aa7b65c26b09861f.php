<div>
    <article class="bg-gray-100 shadow rounded mb-1" x-data="{open: false}">
        <header>
            <button @click="open = !open; if (open) $nextTick(()=>{ $refs.descTextarea.focus() });" class="block w-full text-left py-2 px-3 rounded focus:ring-2 focus:ring-gray-300 focus:outline-none">Descripción de la lección</button>
        </header>
        <div class="py-2 px-3 border-t border-gray-200" x-show="open">
            <?php if($lesson->description): ?>
                <form wire:submit.prevent="update" class="flex flex-col md:flex-row md:gap-3">
                    <div class="flex-1">
                        <textarea wire:model="description.name" x-ref="descTextarea" name="description" id="description-<?php echo e($lesson->id); ?>" spellcheck="false" rows="3" class="form-input <?php if($errors->has('description.name')): ?> invalid <?php endif; ?>"></textarea>
                    </div>

                    <div class="flex md:flex-col gap-2">
                        <button wire:click="destroy" class="btn btn-red" type="button">Eliminar</button>
                        <button class="btn btn-blue" type="submit">Actualizar</button>
                    </div>
                </form>
                <?php $__errorArgs = ['description.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php else: ?>
                <div wire:submit.prevent="update" class="flex gap-3">
                    <div class="flex-1">
                        <textarea wire:model="name" name="description" id="description-<?php echo e($lesson->id); ?>" spellcheck="false" rows="3" class="form-input <?php if($errors->has('description.name')): ?> invalid <?php endif; ?>" placeholder="Escriba una descripción para ésta lección..."></textarea>
                    </div>

                    <div class="flex flex-col gap-2">
                        <button wire:click="store" class="btn btn-blue" type="button">Guardar</button>
                    </div>
                </div>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>
        </div>
    </article>
</div>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/livewire/instructor/lesson-description.blade.php ENDPATH**/ ?>