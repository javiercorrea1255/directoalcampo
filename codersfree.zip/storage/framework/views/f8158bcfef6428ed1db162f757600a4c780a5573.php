<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-700 text-white py-12">
        <div class="container">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <figure class="">
                    <?php if($course->image): ?>
                        <img class="h-60 w-full object-cover" src="<?php echo e(Storage::url($course->image->url)); ?>" alt="<?php echo e($course->title); ?>">
                    <?php else: ?>
                        <img class="h-60 w-full object-cover" src="<?php echo e(asset('img/courses/placeholder-course-image.png')); ?>" alt="<?php echo e($course->title); ?>">
                    <?php endif; ?>
                </figure>
                <div>
                    <h1 class="text-4xl"><?php echo e($course->title); ?></h1>
                    <h2 class="text-xl mb-3"><?php echo e($course->subtitle); ?></h2>
                    <p class="mb-1">Nivel: <?php echo e($course->level->name); ?></p>
                    <p class="mb-1">Categoría: <?php echo e($course->category->name); ?></p>
                    <p class="mb-1">Matriculados: <?php echo e($course->students_count); ?></p>
                    <p class="mb-1">Calificación: <?php echo e($course->rating); ?></p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-12">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

            <?php if(session('info')): ?>
                <div class="lg:col-span-3">
                    <div class="alert alert-red">
                        <div class="mr-2">
                            <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div class="flex-1"><b>Ha ocurrido un error!</b> <?php echo e(session('info')); ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="order-2 lg:col-span-2 lg:order-1">

                
                <section class="card text-gray-700 mb-6 lg:mb-12">
                    <div class="card-body">
                        <h1 class="font-bold text-xl mb-4">Lo que aprenderás</h1>
                        <ul class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1">
                            <?php $__empty_1 = true; $__currentLoopData = $course->goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="text-base">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="inline text-gray-300 mr-1" viewBox="0 0 16 16">
                                        <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
                                    </svg> <?php echo e($goal->name); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-gray-400">No se han agregado metas a este curso</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </section>

                
                <section class="card text-gray-700 mb-6 lg:mb-12">
                    <div class="card-body">
                        <h1 class="font-bold text-xl mb-4">Temario</h1>
                        <?php $__empty_1 = true; $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article class="mb-4 rounded shadow" <?php if($loop->first): ?> x-data="{ open: true } <?php else: ?> x-data="{ open: false } <?php endif; ?>">
                                <header class="border border-gray-200 bg-gray-200 rounded cursor-pointer px-4 py-2" x-on:click="open = !open">
                                    <h1 class="font-bold text-gray-600"><?php echo e($section->name); ?></h1>
                                </header>
                                <div class="bg-white py-4 px-4" x-show="open">
                                    <ul class="grid grid-cols-1 gap-2">
                                        <?php $__empty_2 = true; $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            <li class="text-gray-700 text-base">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="inline text-gray-300 mr-1" viewBox="0 0 16 16">
                                                    <path d="M0 12V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm6.79-6.907A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"/>
                                                </svg> <?php echo e($lesson->name); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <li class="text-gray-400">No se han agregado lecciones a esta sección</li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-400">No se han agregado secciones a este curso</p>
                        <?php endif; ?>
                    </div>
                </section>

                
                <section class="card text-gray-700 mb-6 lg:mb-12">
                    <div class="card-body">
                        <h1 class="font-bold text-xl mb-4">Requisitos</h1>
                        <ul class="list-disc list-inside">
                            <?php $__empty_1 = true; $__currentLoopData = $course->requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="text-base"><?php echo e($requirement->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-400">No se han agregado requisitos a este curso</p>
                            <?php endif; ?>
                        </ul>
                    </div>
                </section>

                
                <section class="card text-gray-700 mb-6 lg:mb-12">
                    <div class="card-body">
                        <h1 class="font-bold text-xl mb-4">Descripción del curso</h1>
                        <?php if($course->description): ?>
                            <p class="text-gray-700"><?php echo $course->description; ?></p>
                        <?php else: ?>
                            <p class="text-gray-400">No se han agregado descripción a este curso</p>
                        <?php endif; ?>
                    </div>
                </section>

            </div>
            <div class="order-1 lg:order-2">
                <section class="card text-gray-700 mb-6 lg:mb-12">
                    <div class="card-body">
                        <div class="flex items-center mb-4">
                            <figure class="flex-shrink-0 mr-4">
                                <img class="h-12 w-12 object-cover rounded-full shadow" src="<?php echo e($course->teacher->profile_photo_url); ?>" alt="<?php echo e($course->teacher->name); ?>">
                            </figure>
                            <div>
                                <h1 class="font-bold text-gray-500">Prof. <?php echo e($course->teacher->name); ?></h1>
                                <a class="text-gray-400 text-sm" href=""><?php echo e('@' . Str::slug($course->teacher->name, '')); ?></a>
                            </div>
                        </div>

                        <form action="<?php echo e(route('admin.courses.approved', $course)); ?>" class="mb-2" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-green btn-block">
                                Aprobar curso
                                <svg class="inline h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                            </button>
                        </form>

                        <a href="<?php echo e(route('admin.courses.observation', $course)); ?>" class="btn btn-red btn-block">
                            Realizar observación
                            <svg class="inline h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                            </svg>
                        </a>
                    </div>
                </section>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/admin/courses/show.blade.php ENDPATH**/ ?>