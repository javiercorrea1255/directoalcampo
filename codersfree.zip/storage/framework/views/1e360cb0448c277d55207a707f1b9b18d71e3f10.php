<div class="px-4 py-3">
    <?php $__empty_1 = true; $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="bg-white shadow rounded mb-1" x-data="{open: false}">
            <?php if($lesson->id == $item->id): ?>
                <form wire:submit.prevent="update" class="py-2 px-3">
                    <div class="grid grid-col-1 md:grid-cols-6 items-center md:gap-3 mb-2">
                        <label for="edit-lesson-name-<?php echo e($section->id); ?>">Nombre</label>
                        <div class="md:col-span-5">
                            <input wire:model="lesson.name" id="edit-lesson-name-<?php echo e($section->id); ?>" type="text" class="form-input <?php if($errors->has('lesson.name')): ?> invalid <?php endif; ?>">
                            <?php $__errorArgs = ['lesson.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="grid grid-col-1 md:grid-cols-6 items-center md:gap-3 mb-2">
                        <label for="edit-lesson-platform-<?php echo e($section->id); ?>">Plataforma</label>
                        <div class="md:col-span-5">
                            <select wire:model="lesson.platform_id" id="edit-lesson-platform-<?php echo e($section->id); ?>" type="text" class="form-input <?php if($errors->has('lesson.platform')): ?> invalid <?php endif; ?>">
                                <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['lesson.platform'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="grid grid-col-1 md:grid-cols-6 items-center md:gap-3 mb-2">
                        <label for="edit-lesson-url-<?php echo e($section->id); ?>">URL</label>
                        <div class="md:col-span-5">
                            <input wire:model="lesson.url" id="edit-lesson-url-<?php echo e($section->id); ?>" type="text" class="form-input <?php if($errors->has('lesson.url')): ?> invalid <?php endif; ?>">
                            <?php $__errorArgs = ['lesson.url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="flex justify-end gap-2">
                        <button wire:click="cancel" type="button" class="btn">Cancelar</button>
                        <button type="submit" class="btn btn-blue">Actualizar</button>
                    </div>
                </form>
            <?php else: ?>
                <header>
                    <button @click="open = !open" class="flex justify-between items-center w-full text-left py-2 px-3 rounded focus:ring-2 focus:ring-gray-300 focus:outline-none">
                        <div>
                            <svg class="inline w-5 h-5 text-gray-400 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <?php echo e($item->name); ?>

                        </div>
                        <svg class="inline h-5 h-5 text-gray-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                    </button>
                </header>
                <div class="py-2 px-3 border-t border-gray-100" x-show="open">
                    <ul>
                        <li><b>Plataforma:</b> <?php echo e($item->platform->name); ?></li>
                        <li><b>Enlace:</b> <a href="<?php echo e($item->url); ?>" class="text-gray-400 underline" target="_blank"><?php echo e($item->url); ?></a></li>
                    </ul>
                    <div class="my-2">
                        <button wire:click="edit(<?php echo e($item); ?>)" class="btn btn-blue" type="button">Editar</button>
                        <button wire:click="destroy(<?php echo e($item); ?>)" class="btn btn-red" type="button">Eliminar</button>
                    </div>

                    <div class="mb-3">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.lesson-description', ['lesson' => $item])->html();
} elseif ($_instance->childHasBeenRendered('lesson-description' . $item->id)) {
    $componentId = $_instance->getRenderedChildComponentId('lesson-description' . $item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('lesson-description' . $item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lesson-description' . $item->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.lesson-description', ['lesson' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild('lesson-description' . $item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="mb-3">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.lesson-resource', ['lesson' => $item])->html();
} elseif ($_instance->childHasBeenRendered('lesson-resource' . $item->id)) {
    $componentId = $_instance->getRenderedChildComponentId('lesson-resource' . $item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('lesson-resource' . $item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lesson-resource' . $item->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.lesson-resource', ['lesson' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild('lesson-resource' . $item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            <?php endif; ?>

        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-center">
            Aun no hay lecciones en esta sección
        </div>
    <?php endif; ?>

    
    <div class="mt-4" x-data="{open: false}">
        <div class="text-center mb-3">
            <button class="btn" type="button" @click="open = true; if (open) $nextTick(()=>{ $refs.lessonName.focus() });" x-show="!open">
                <svg class="inline w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                </svg> Agregar nueva lección
            </button>
        </div>
        <article class="bg-white rounded shadow px-4 py-3 mb-3" x-show="open">
            <h1 class="text-lg font-bold mb-3">Nueva lección</h1>
            <div class="grid grid-col-1 md:grid-cols-6 items-center md:gap-3 mb-2">
                <label for="name-<?php echo e($section->id); ?>">Nombre</label>
                <div class="md:col-span-5">
                    <input wire:model="name" id="name-<?php echo e($section->id); ?>" x-ref="lessonName" type="text" class="form-input <?php if($errors->has('name')): ?> invalid <?php endif; ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="grid grid-col-1 md:grid-cols-6 items-center md:gap-3 mb-2">
                <label for="platform-<?php echo e($section->id); ?>">Plataforma</label>
                <div class="md:col-span-5">
                    <select wire:model="platform_id" id="platform-<?php echo e($section->id); ?>" type="text" class="form-input <?php if($errors->has('platform_id')): ?> invalid <?php endif; ?>">
                        <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['platform_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="grid grid-col-1 md:grid-cols-6 items-center md:gap-3 mb-2">
                <label for="url-<?php echo e($section->id); ?>">URL</label>
                <div class="md:col-span-5">
                    <input wire:model="url" id="url-<?php echo e($section->id); ?>" type="text" class="form-input <?php if($errors->has('url')): ?> invalid <?php endif; ?>">
                    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <b class="block text-xs text-red-500 mt-1"><?php echo e($message); ?></b>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="flex justify-end gap-2">
                <button wire:click="cancel" @click="open = false" type="button" class="btn">Cancelar</button>
                <button wire:click="store" class="btn btn-blue">Crear</button>
            </div>
        </article>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/livewire/instructor/courses-lesson.blade.php ENDPATH**/ ?>