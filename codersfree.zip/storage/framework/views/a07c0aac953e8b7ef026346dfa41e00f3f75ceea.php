<?php $__env->startSection('title', 'Course Free'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Niveles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success mb-4 alert-dismissible fade show" role="alert">
        <strong>Holy guacamole!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <a href="<?php echo e(route('admin.levels.create')); ?>" class="btn btn-primary">Crear nivel</a>
        </div>
        <div class="card-body p-0">
              <table class="table table-striped">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col" colspan="2"></th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td scope="row"><?php echo e($level->id); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.levels.edit', $level)); ?>"><?php echo e($level->name); ?></a>
                        </td>
                        <td width="1rem">
                            <a class="btn btn-secondary btn-sm" href="<?php echo e(route('admin.levels.edit', $level)); ?>">Editar</a>
                        </td>
                        <td width="1rem">
                            <form action="<?php echo e(route('admin.levels.destroy', $level)); ?>" method="POST">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No se encontraron registros.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
              </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/admin/levels/index.blade.php ENDPATH**/ ?>