<div>

   <article class="card relative">
      <div wire:loading.flex class="absolute w-full h-full bg-gray-100 bg-opacity-25 z-30  items-center justify-center">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.spinner','data' => ['size' => '20']]); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['size' => '20']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
      </div>
      <form action="" id="card-form">
         <div class="card-body">
            <h1 class="text-gray-700 text-lg font-bold mb-4">Agregar método de pago</h1>
         
            <div class="flex">
               <p class="text-gray-700">Información de la tarjeta</p>
               <div class="flex-1 ml-6">

               <div class="form-group">
                  <input class="form-control" id="card-holder-name" type="text" placeholder="Nombre del titular de la tarjeta" required>
               </div>
                  

                  <!-- Stripe Elements Placeholder -->
                  <div>
                     <div class="form-control" id="card-element"></div>

                     <span class="invalid-feedback" id="cardErrors"></span>
                  </div>
               </div>

            </div>



      </div>


         </div>

         <div class="card-footer bg-gray-50 flex justify-end">
            <button class="btn btn-primary" id="card-button" data-secret="<?php echo e($intent->client_secret); ?>">
               Actualizar método de pago
            </button>
         </div>
      </form>
   </article>
        

      <?php $__env->slot('js'); ?>

      <script>
         document.addEventListener('livewire:load',function(){
            stripe();
         }) 

         Livewire.on('resetStripe', function(){
            document.getElementById('card-form').reset();
            stripe();

         });
      </script>
         <script>
            function stripe(){
            const stripe = Stripe("<?php echo e(env('STRIPE_KEY')); ?>");
      
            const elements = stripe.elements();
            const cardElement = elements.create('card');
      
            cardElement.mount('#card-element');


                        //generar token
                        const cardHolderName = document.getElementById('card-holder-name');
            const cardButton = document.getElementById('card-button');
            const clientSecret = cardButton.dataset.secret;
            const cardForm =document.getElementById('card-form');

            cardForm.addEventListener('submit', async (e) => {
               e.preventDefault();
               const { setupIntent, error } = await stripe.confirmCardSetup(
                  clientSecret, {
                        payment_method: {
                           card: cardElement,
                           billing_details: { name: cardHolderName.value }
                        }
                  }
               );

               if (error) {
                  document.getElementById('cardErrors').textContent = error.message;
               } else {
                  Livewire.emit('paymentMethodCreate',setupIntent.payment_method);
               }
            });
         }

                  </script>
                     
                  <?php $__env->endSlot(); ?>
            </div>
<?php /**PATH C:\xampp\htdocs\codersfree\resources\views/livewire/payment-method-create.blade.php ENDPATH**/ ?>