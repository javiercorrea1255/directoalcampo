<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="pb-12">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('subscriptions')->html();
} elseif ($_instance->childHasBeenRendered('mgIs2L8')) {
    $componentId = $_instance->getRenderedChildComponentId('mgIs2L8');
    $componentTag = $_instance->getRenderedChildComponentTagName('mgIs2L8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mgIs2L8');
} else {
    $response = \Livewire\Livewire::mount('subscriptions');
    $html = $response->html();
    $_instance->logRenderedChild('mgIs2L8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-method-create')->html();
} elseif ($_instance->childHasBeenRendered('uAJGnU6')) {
    $componentId = $_instance->getRenderedChildComponentId('uAJGnU6');
    $componentTag = $_instance->getRenderedChildComponentTagName('uAJGnU6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uAJGnU6');
} else {
    $response = \Livewire\Livewire::mount('payment-method-create');
    $html = $response->html();
    $_instance->logRenderedChild('uAJGnU6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="mt-8">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-method-list')->html();
} elseif ($_instance->childHasBeenRendered('RLMkuw7')) {
    $componentId = $_instance->getRenderedChildComponentId('RLMkuw7');
    $componentTag = $_instance->getRenderedChildComponentTagName('RLMkuw7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RLMkuw7');
} else {
    $response = \Livewire\Livewire::mount('payment-method-list');
    $html = $response->html();
    $_instance->logRenderedChild('RLMkuw7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            
        </div>

   

    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\codersfree\resources\views/billing/index.blade.php ENDPATH**/ ?>